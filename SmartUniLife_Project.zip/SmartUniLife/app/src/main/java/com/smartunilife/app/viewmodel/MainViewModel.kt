package com.smartunilife.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartunilife.app.data.database.AppDatabase
import com.smartunilife.app.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = AppDatabase.getDatabase(application)
    private val userRepository = UserRepository(database.userDao())
    
    private val _authState = MutableStateFlow(AuthState.LOADING)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    enum class AuthState {
        LOADING,
        AUTHENTICATED,
        UNAUTHENTICATED,
        NEEDS_ONBOARDING
    }
    
    fun checkAuthenticationState() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                
                val currentUser = userRepository.getCurrentUser()
                
                if (currentUser == null) {
                    _authState.value = AuthState.NEEDS_ONBOARDING
                } else {
                    // User exists, but we need to verify authentication
                    // For now, we'll assume they need to authenticate
                    _authState.value = AuthState.UNAUTHENTICATED
                }
                
            } catch (e: Exception) {
                _authState.value = AuthState.NEEDS_ONBOARDING
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun setAuthenticated() {
        _authState.value = AuthState.AUTHENTICATED
    }
    
    fun logout() {
        _authState.value = AuthState.UNAUTHENTICATED
    }
}
