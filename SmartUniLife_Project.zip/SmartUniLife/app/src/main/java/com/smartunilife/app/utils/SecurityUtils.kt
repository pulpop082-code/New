package com.smartunilife.app.utils

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.SecretKeyFactory

object SecurityUtils {
    
    private const val PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val PBKDF2_ITERATIONS = 100000
    private const val SALT_LENGTH = 32
    private const val AES_ALGORITHM = "AES"
    private const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_IV_LENGTH = 12
    private const val GCM_TAG_LENGTH = 16
    
    /**
     * Generate a random salt for password hashing
     */
    fun generateSalt(): String {
        val salt = ByteArray(SALT_LENGTH)
        SecureRandom().nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }
    
    /**
     * Hash a password using PBKDF2 with the provided salt
     */
    fun hashPassword(password: String, salt: String): String {
        val saltBytes = Base64.decode(salt, Base64.NO_WRAP)
        val spec = PBEKeySpec(password.toCharArray(), saltBytes, PBKDF2_ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM)
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }
    
    /**
     * Generate a random AES key
     */
    fun generateAESKey(): SecretKey {
        val keyGenerator = KeyGenerator.getInstance(AES_ALGORITHM)
        keyGenerator.init(256)
        return keyGenerator.generateKey()
    }
    
    /**
     * Derive an AES key from a password and salt
     */
    fun deriveKeyFromPassword(password: String, salt: String): SecretKey {
        val saltBytes = Base64.decode(salt, Base64.NO_WRAP)
        val spec = PBEKeySpec(password.toCharArray(), saltBytes, PBKDF2_ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM)
        val keyBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, AES_ALGORITHM)
    }
    
    /**
     * Encrypt data using AES-GCM
     */
    fun encryptData(data: ByteArray, key: SecretKey): ByteArray {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        
        val iv = cipher.iv
        val encryptedData = cipher.doFinal(data)
        
        // Combine IV and encrypted data
        val result = ByteArray(iv.size + encryptedData.size)
        System.arraycopy(iv, 0, result, 0, iv.size)
        System.arraycopy(encryptedData, 0, result, iv.size, encryptedData.size)
        
        return result
    }
    
    /**
     * Decrypt data using AES-GCM
     */
    fun decryptData(encryptedData: ByteArray, key: SecretKey): ByteArray {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        
        // Extract IV and encrypted data
        val iv = ByteArray(GCM_IV_LENGTH)
        val cipherText = ByteArray(encryptedData.size - GCM_IV_LENGTH)
        System.arraycopy(encryptedData, 0, iv, 0, iv.size)
        System.arraycopy(encryptedData, iv.size, cipherText, 0, cipherText.size)
        
        val spec = GCMParameterSpec(GCM_TAG_LENGTH * 8, iv)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)
        
        return cipher.doFinal(cipherText)
    }
    
    /**
     * Encrypt a string and return Base64 encoded result
     */
    fun encryptString(plainText: String, key: SecretKey): String {
        val encryptedBytes = encryptData(plainText.toByteArray(Charsets.UTF_8), key)
        return Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
    }
    
    /**
     * Decrypt a Base64 encoded string
     */
    fun decryptString(encryptedText: String, key: SecretKey): String {
        val encryptedBytes = Base64.decode(encryptedText, Base64.NO_WRAP)
        val decryptedBytes = decryptData(encryptedBytes, key)
        return String(decryptedBytes, Charsets.UTF_8)
    }
    
    /**
     * Generate SHA-256 hash of data
     */
    fun sha256Hash(data: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(data.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(hashBytes, Base64.NO_WRAP)
    }
    
    /**
     * Generate a secure random string for various purposes
     */
    fun generateSecureRandomString(length: Int): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        val random = SecureRandom()
        val result = StringBuilder(length)
        
        repeat(length) {
            result.append(chars[random.nextInt(chars.length)])
        }
        
        return result.toString()
    }
}
