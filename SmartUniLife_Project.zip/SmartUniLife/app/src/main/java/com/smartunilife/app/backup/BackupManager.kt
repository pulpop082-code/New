package com.smartunilife.app.backup

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.smartunilife.app.data.database.AppDatabase
import com.smartunilife.app.data.entity.*
import com.smartunilife.app.utils.SecurityUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.SecretKey

class BackupManager(private val context: Context) {
    
    private val database = AppDatabase.getDatabase(context)
    
    data class BackupOptions(
        val includeMedia: Boolean = false,
        val password: String,
        val destinationUri: Uri? = null
    )
    
    data class RestoreOptions(
        val backupUri: Uri,
        val password: String,
        val mergeData: Boolean = true // true = merge, false = overwrite
    )
    
    suspend fun createBackup(options: BackupOptions): Result<String> = withContext(Dispatchers.IO) {
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
            val filename = "smartunilife_backup_${timestamp}.smartbak"
            
            // Get current user
            val currentUser = database.userDao().getCurrentUser()
                ?: return@withContext Result.failure(Exception("No user found"))
            
            // Create backup data structure
            val backupData = JSONObject().apply {
                put("version", 1)
                put("timestamp", System.currentTimeMillis())
                put("user", currentUser.username)
                put("includeMedia", options.includeMedia)
                
                // Export user data
                put("userData", exportUserData(currentUser))
                
                // Export courses
                put("courses", exportCourses())
                
                // Export lectures
                put("lectures", exportLectures())
                
                // Export assignments
                put("assignments", exportAssignments())
                
                // Export grades
                put("grades", exportGrades())
                
                // Export media metadata
                put("media", exportMediaMetadata())
            }
            
            // Create encrypted backup file
            val backupBytes = backupData.toString().toByteArray(Charsets.UTF_8)
            val salt = SecurityUtils.generateSalt()
            val key = SecurityUtils.deriveKeyFromPassword(options.password, salt)
            val encryptedData = SecurityUtils.encryptData(backupBytes, key)
            
            // Create final backup file with salt + encrypted data
            val finalBackup = ByteArrayOutputStream().use { baos ->
                // Write salt first
                val saltBytes = android.util.Base64.decode(salt, android.util.Base64.NO_WRAP)
                baos.write(saltBytes)
                // Write encrypted data
                baos.write(encryptedData)
                baos.toByteArray()
            }
            
            // Save to destination
            val savedPath = if (options.destinationUri != null) {
                saveBackupToUri(options.destinationUri, filename, finalBackup, options.includeMedia)
            } else {
                saveBackupToInternalStorage(filename, finalBackup)
            }
            
            Result.success(savedPath)
            
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun restoreBackup(options: RestoreOptions): Result<String> = withContext(Dispatchers.IO) {
        try {
            // Read backup file
            val backupBytes = readBackupFile(options.backupUri)
            
            // Extract salt and encrypted data
            val saltBytes = backupBytes.sliceArray(0..31) // First 32 bytes are salt
            val encryptedData = backupBytes.sliceArray(32 until backupBytes.size)
            val salt = android.util.Base64.encodeToString(saltBytes, android.util.Base64.NO_WRAP)
            
            // Decrypt data
            val key = SecurityUtils.deriveKeyFromPassword(options.password, salt)
            val decryptedBytes = SecurityUtils.decryptData(encryptedData, key)
            val backupJson = String(decryptedBytes, Charsets.UTF_8)
            
            // Parse backup data
            val backupData = JSONObject(backupJson)
            val version = backupData.getInt("version")
            
            if (version != 1) {
                return@withContext Result.failure(Exception("Unsupported backup version: $version"))
            }
            
            // Start database transaction
            database.runInTransaction {
                if (!options.mergeData) {
                    // Clear existing data
                    clearAllData()
                }
                
                // Restore user data
                restoreUserData(backupData.getJSONObject("userData"))
                
                // Restore courses
                restoreCourses(backupData.getJSONArray("courses"))
                
                // Restore lectures
                restoreLectures(backupData.getJSONArray("lectures"))
                
                // Restore assignments
                restoreAssignments(backupData.getJSONArray("assignments"))
                
                // Restore grades
                restoreGrades(backupData.getJSONArray("grades"))
                
                // Restore media metadata
                restoreMediaMetadata(backupData.getJSONArray("media"))
            }
            
            Result.success("Backup restored successfully")
            
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    private suspend fun exportUserData(user: UserEntity): JSONObject {
        return JSONObject().apply {
            put("username", user.username)
            put("passwordHash", user.passwordHash)
            put("major", user.major)
            put("salt", user.salt)
            put("createdAt", user.createdAt)
            put("securityQuestion", user.securityQuestion)
            put("securityAnswerHash", user.securityAnswerHash)
            put("biometricEnabled", user.biometricEnabled)
            put("pinEnabled", user.pinEnabled)
            put("pinHash", user.pinHash)
        }
    }
    
    private suspend fun exportCourses(): JSONArray {
        val courses = database.courseDao().getAllCourses()
        val jsonArray = JSONArray()
        
        courses.forEach { course ->
            jsonArray.put(JSONObject().apply {
                put("courseId", course.courseId)
                put("name", course.name)
                put("code", course.code)
                put("professorName", course.professorName)
                put("professorPhone", course.professorPhone)
                put("colorHex", course.colorHex)
                put("createdAt", course.createdAt)
                put("weeklySchedule", course.weeklySchedule)
                put("room", course.room)
            })
        }
        
        return jsonArray
    }
    
    private suspend fun exportLectures(): JSONArray {
        val lectures = mutableListOf<LectureEntity>()
        val courses = database.courseDao().getAllCourses()
        
        courses.forEach { course ->
            lectures.addAll(database.lectureDao().getLecturesByCourseId(course.courseId))
        }
        
        val jsonArray = JSONArray()
        lectures.forEach { lecture ->
            jsonArray.put(JSONObject().apply {
                put("lectureId", lecture.lectureId)
                put("courseOwnerId", lecture.courseOwnerId)
                put("index", lecture.index)
                put("title", lecture.title)
                put("dateTime", lecture.dateTime)
                put("durationMinutes", lecture.durationMinutes)
                put("room", lecture.room)
                put("attended", lecture.attended)
                put("notes", lecture.notes)
                put("audioFilePath", lecture.audioFilePath)
                put("isRecording", lecture.isRecording)
            })
        }
        
        return jsonArray
    }
    
    private suspend fun exportAssignments(): JSONArray {
        val assignments = mutableListOf<AssignmentEntity>()
        val courses = database.courseDao().getAllCourses()
        
        courses.forEach { course ->
            assignments.addAll(database.assignmentDao().getAssignmentsByCourseId(course.courseId))
        }
        
        val jsonArray = JSONArray()
        assignments.forEach { assignment ->
            jsonArray.put(JSONObject().apply {
                put("assignmentId", assignment.assignmentId)
                put("courseOwnerId", assignment.courseOwnerId)
                put("title", assignment.title)
                put("description", assignment.description)
                put("dueDateTime", assignment.dueDateTime)
                put("weight", assignment.weight)
                put("completed", assignment.completed)
                put("reminderOffsets", assignment.reminderOffsets)
                put("createdAt", assignment.createdAt)
            })
        }
        
        return jsonArray
    }
    
    private suspend fun exportGrades(): JSONArray {
        val grades = mutableListOf<GradeEntity>()
        val courses = database.courseDao().getAllCourses()
        
        courses.forEach { course ->
            grades.addAll(database.gradeDao().getGradesByCourseId(course.courseId))
        }
        
        val jsonArray = JSONArray()
        grades.forEach { grade ->
            jsonArray.put(JSONObject().apply {
                put("gradeId", grade.gradeId)
                put("courseOwnerId", grade.courseOwnerId)
                put("type", grade.type)
                put("title", grade.title)
                put("score", grade.score)
                put("maxScore", grade.maxScore)
                put("weight", grade.weight)
                put("date", grade.date)
                put("assignmentId", grade.assignmentId)
            })
        }
        
        return jsonArray
    }
    
    private suspend fun exportMediaMetadata(): JSONArray {
        // This would export media file metadata
        // Actual media files would be included in the backup if requested
        return JSONArray()
    }
    
    private fun saveBackupToUri(uri: Uri, filename: String, data: ByteArray, includeMedia: Boolean): String {
        val documentFile = DocumentFile.fromTreeUri(context, uri)
        val backupFile = documentFile?.createFile("application/octet-stream", filename)
        
        backupFile?.let { file ->
            context.contentResolver.openOutputStream(file.uri)?.use { outputStream ->
                if (includeMedia) {
                    // Create ZIP file with backup data and media files
                    ZipOutputStream(outputStream).use { zipOut ->
                        // Add backup data
                        zipOut.putNextEntry(ZipEntry("backup.json"))
                        zipOut.write(data)
                        zipOut.closeEntry()
                        
                        // Add media files
                        addMediaFilesToZip(zipOut)
                    }
                } else {
                    // Just write the backup data
                    outputStream.write(data)
                }
            }
        }
        
        return backupFile?.uri?.toString() ?: "Unknown location"
    }
    
    private fun saveBackupToInternalStorage(filename: String, data: ByteArray): String {
        val backupDir = File(context.getExternalFilesDir(null), "backups")
        if (!backupDir.exists()) {
            backupDir.mkdirs()
        }
        
        val backupFile = File(backupDir, filename)
        backupFile.writeBytes(data)
        
        return backupFile.absolutePath
    }
    
    private fun readBackupFile(uri: Uri): ByteArray {
        return context.contentResolver.openInputStream(uri)?.use { inputStream ->
            inputStream.readBytes()
        } ?: throw Exception("Could not read backup file")
    }
    
    private fun addMediaFilesToZip(zipOut: ZipOutputStream) {
        // This would add media files to the ZIP archive
        // Implementation depends on how media files are stored
    }
    
    private suspend fun clearAllData() {
        // Clear all tables except user data if merging is disabled
        database.gradeDao().deleteGradesByCourseId(-1) // This would need a proper implementation
        database.mediaDao().deleteMediaByCourseId(-1)
        database.assignmentDao().deleteAssignment(AssignmentEntity(0, 0, "", "", 0)) // Placeholder
        database.lectureDao().deleteLecture(LectureEntity(0, 0, 0, "", 0, 0)) // Placeholder
        database.courseDao().deleteCourse(CourseEntity(0, "", "", "", "", "", 0)) // Placeholder
    }
    
    private suspend fun restoreUserData(userData: JSONObject) {
        val user = UserEntity(
            username = userData.getString("username"),
            passwordHash = userData.getString("passwordHash"),
            major = userData.getString("major"),
            salt = userData.getString("salt"),
            createdAt = userData.getLong("createdAt"),
            securityQuestion = userData.optString("securityQuestion").takeIf { it.isNotEmpty() },
            securityAnswerHash = userData.optString("securityAnswerHash").takeIf { it.isNotEmpty() },
            biometricEnabled = userData.optBoolean("biometricEnabled", false),
            pinEnabled = userData.optBoolean("pinEnabled", false),
            pinHash = userData.optString("pinHash").takeIf { it.isNotEmpty() }
        )
        
        database.userDao().insertUser(user)
    }
    
    private suspend fun restoreCourses(coursesArray: JSONArray) {
        for (i in 0 until coursesArray.length()) {
            val courseJson = coursesArray.getJSONObject(i)
            val course = CourseEntity(
                courseId = courseJson.getLong("courseId"),
                name = courseJson.getString("name"),
                code = courseJson.optString("code").takeIf { it.isNotEmpty() },
                professorName = courseJson.optString("professorName").takeIf { it.isNotEmpty() },
                professorPhone = courseJson.optString("professorPhone").takeIf { it.isNotEmpty() },
                colorHex = courseJson.optString("colorHex").takeIf { it.isNotEmpty() },
                createdAt = courseJson.getLong("createdAt"),
                weeklySchedule = courseJson.optString("weeklySchedule").takeIf { it.isNotEmpty() },
                room = courseJson.optString("room").takeIf { it.isNotEmpty() }
            )
            
            database.courseDao().insertCourse(course)
        }
    }
    
    private suspend fun restoreLectures(lecturesArray: JSONArray) {
        for (i in 0 until lecturesArray.length()) {
            val lectureJson = lecturesArray.getJSONObject(i)
            val lecture = LectureEntity(
                lectureId = lectureJson.getLong("lectureId"),
                courseOwnerId = lectureJson.getLong("courseOwnerId"),
                index = lectureJson.getInt("index"),
                title = lectureJson.optString("title").takeIf { it.isNotEmpty() },
                dateTime = lectureJson.getLong("dateTime"),
                durationMinutes = lectureJson.getInt("durationMinutes"),
                room = lectureJson.optString("room").takeIf { it.isNotEmpty() },
                attended = lectureJson.getBoolean("attended"),
                notes = lectureJson.optString("notes").takeIf { it.isNotEmpty() },
                audioFilePath = lectureJson.optString("audioFilePath").takeIf { it.isNotEmpty() },
                isRecording = lectureJson.optBoolean("isRecording", false)
            )
            
            database.lectureDao().insertLecture(lecture)
        }
    }
    
    private suspend fun restoreAssignments(assignmentsArray: JSONArray) {
        for (i in 0 until assignmentsArray.length()) {
            val assignmentJson = assignmentsArray.getJSONObject(i)
            val assignment = AssignmentEntity(
                assignmentId = assignmentJson.getLong("assignmentId"),
                courseOwnerId = assignmentJson.getLong("courseOwnerId"),
                title = assignmentJson.getString("title"),
                description = assignmentJson.optString("description").takeIf { it.isNotEmpty() },
                dueDateTime = assignmentJson.getLong("dueDateTime"),
                weight = assignmentJson.optDouble("weight").takeIf { !it.isNaN() }?.toFloat(),
                completed = assignmentJson.getBoolean("completed"),
                reminderOffsets = assignmentJson.optString("reminderOffsets").takeIf { it.isNotEmpty() },
                createdAt = assignmentJson.getLong("createdAt")
            )
            
            database.assignmentDao().insertAssignment(assignment)
        }
    }
    
    private suspend fun restoreGrades(gradesArray: JSONArray) {
        for (i in 0 until gradesArray.length()) {
            val gradeJson = gradesArray.getJSONObject(i)
            val grade = GradeEntity(
                gradeId = gradeJson.getLong("gradeId"),
                courseOwnerId = gradeJson.getLong("courseOwnerId"),
                type = gradeJson.getString("type"),
                title = gradeJson.optString("title").takeIf { it.isNotEmpty() },
                score = gradeJson.getDouble("score").toFloat(),
                maxScore = gradeJson.getDouble("maxScore").toFloat(),
                weight = gradeJson.optDouble("weight").takeIf { !it.isNaN() }?.toFloat(),
                date = gradeJson.getLong("date"),
                assignmentId = gradeJson.optLong("assignmentId").takeIf { it != 0L }
            )
            
            database.gradeDao().insertGrade(grade)
        }
    }
    
    private suspend fun restoreMediaMetadata(mediaArray: JSONArray) {
        // Restore media metadata
        // Actual media files would need to be extracted from ZIP if included
    }
}
