package com.smartunilife.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartunilife.app.data.database.AppDatabase
import com.smartunilife.app.data.entity.UserEntity
import com.smartunilife.app.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = AppDatabase.getDatabase(application)
    private val userRepository = UserRepository(database.userDao())
    
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()
    
    private val _authState = MutableStateFlow(AuthState.IDLE)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    private val _errorMessage = MutableStateFlow("")
    val errorMessage: StateFlow<String> = _errorMessage.asStateFlow()
    
    enum class AuthState {
        IDLE,
        LOADING,
        SUCCESS,
        ERROR
    }
    
    fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val user = userRepository.getCurrentUser()
                _currentUser.value = user
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load user data"
            }
        }
    }
    
    fun authenticateWithPassword(password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.LOADING
            try {
                val user = _currentUser.value
                if (user != null) {
                    val isValid = userRepository.authenticateUser(user.username, password)
                    if (isValid) {
                        _authState.value = AuthState.SUCCESS
                    } else {
                        _authState.value = AuthState.ERROR
                        _errorMessage.value = "Invalid password"
                    }
                } else {
                    _authState.value = AuthState.ERROR
                    _errorMessage.value = "User not found"
                }
            } catch (e: Exception) {
                _authState.value = AuthState.ERROR
                _errorMessage.value = "Authentication failed"
            }
        }
    }
    
    fun authenticateWithPin(pin: String) {
        viewModelScope.launch {
            _authState.value = AuthState.LOADING
            try {
                val user = _currentUser.value
                if (user != null) {
                    val isValid = userRepository.verifyPin(user.username, pin)
                    if (isValid) {
                        _authState.value = AuthState.SUCCESS
                    } else {
                        _authState.value = AuthState.ERROR
                        _errorMessage.value = "Invalid PIN"
                    }
                } else {
                    _authState.value = AuthState.ERROR
                    _errorMessage.value = "User not found"
                }
            } catch (e: Exception) {
                _authState.value = AuthState.ERROR
                _errorMessage.value = "PIN authentication failed"
            }
        }
    }
    
    fun onBiometricAuthSuccess() {
        _authState.value = AuthState.SUCCESS
    }
    
    fun verifySecurityAnswer(answer: String) {
        viewModelScope.launch {
            _authState.value = AuthState.LOADING
            try {
                val user = _currentUser.value
                if (user != null) {
                    val isValid = userRepository.verifySecurityAnswer(user.username, answer)
                    if (isValid) {
                        _authState.value = AuthState.SUCCESS
                    } else {
                        _authState.value = AuthState.ERROR
                        _errorMessage.value = "Incorrect security answer"
                    }
                } else {
                    _authState.value = AuthState.ERROR
                    _errorMessage.value = "User not found"
                }
            } catch (e: Exception) {
                _authState.value = AuthState.ERROR
                _errorMessage.value = "Security verification failed"
            }
        }
    }
    
    fun clearError() {
        _errorMessage.value = ""
    }
}
