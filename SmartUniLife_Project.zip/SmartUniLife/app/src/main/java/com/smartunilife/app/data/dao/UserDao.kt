package com.smartunilife.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.smartunilife.app.data.entity.UserEntity

@Dao
interface UserDao {
    
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?
    
    @Query("SELECT * FROM users LIMIT 1")
    suspend fun getCurrentUser(): UserEntity?
    
    @Query("SELECT * FROM users LIMIT 1")
    fun getCurrentUserLiveData(): LiveData<UserEntity?>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)
    
    @Update
    suspend fun updateUser(user: UserEntity)
    
    @Delete
    suspend fun deleteUser(user: UserEntity)
    
    @Query("DELETE FROM users")
    suspend fun deleteAllUsers()
    
    @Query("UPDATE users SET passwordHash = :newPasswordHash, salt = :newSalt WHERE username = :username")
    suspend fun updatePassword(username: String, newPasswordHash: String, newSalt: String)
    
    @Query("UPDATE users SET pinHash = :pinHash, pinEnabled = :enabled WHERE username = :username")
    suspend fun updatePin(username: String, pinHash: String?, enabled: Boolean)
    
    @Query("UPDATE users SET biometricEnabled = :enabled WHERE username = :username")
    suspend fun updateBiometricEnabled(username: String, enabled: Boolean)
    
    @Query("UPDATE users SET securityQuestion = :question, securityAnswerHash = :answerHash WHERE username = :username")
    suspend fun updateSecurityQuestion(username: String, question: String, answerHash: String)
}
