package com.smartunilife.app.ui.onboarding

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayoutMediator
import com.smartunilife.app.R
import com.smartunilife.app.databinding.ActivityOnboardingBinding
import com.smartunilife.app.ui.MainActivity
import com.smartunilife.app.ui.onboarding.adapter.OnboardingPagerAdapter
import com.smartunilife.app.viewmodel.OnboardingViewModel
import kotlinx.coroutines.launch

class OnboardingActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityOnboardingBinding
    private val viewModel: OnboardingViewModel by viewModels()
    private lateinit var pagerAdapter: OnboardingPagerAdapter
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupViewPager()
        setupObservers()
        setupClickListeners()
    }
    
    private fun setupViewPager() {
        pagerAdapter = OnboardingPagerAdapter(this)
        binding.viewPager.adapter = pagerAdapter
        
        // Setup tab layout with view pager
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { _, _ ->
            // Tab configuration is handled by the adapter
        }.attach()
        
        // Handle page changes
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateNavigationButtons(position)
            }
        })
    }
    
    private fun setupObservers() {
        lifecycleScope.launch {
            viewModel.onboardingState.collect { state ->
                when (state) {
                    OnboardingViewModel.OnboardingState.LOADING -> {
                        binding.progressBar.visibility = android.view.View.VISIBLE
                        setButtonsEnabled(false)
                    }
                    OnboardingViewModel.OnboardingState.SUCCESS -> {
                        binding.progressBar.visibility = android.view.View.GONE
                        navigateToMain()
                    }
                    OnboardingViewModel.OnboardingState.ERROR -> {
                        binding.progressBar.visibility = android.view.View.GONE
                        setButtonsEnabled(true)
                    }
                    OnboardingViewModel.OnboardingState.IDLE -> {
                        binding.progressBar.visibility = android.view.View.GONE
                        setButtonsEnabled(true)
                    }
                }
            }
        }
        
        lifecycleScope.launch {
            viewModel.errorMessage.collect { message ->
                if (message.isNotEmpty()) {
                    showError(message)
                }
            }
        }
        
        lifecycleScope.launch {
            viewModel.currentStep.collect { step ->
                binding.viewPager.currentItem = step
            }
        }
    }
    
    private fun setupClickListeners() {
        binding.buttonNext.setOnClickListener {
            val currentItem = binding.viewPager.currentItem
            if (currentItem < pagerAdapter.itemCount - 1) {
                binding.viewPager.currentItem = currentItem + 1
            } else {
                // Last step - complete onboarding
                completeOnboarding()
            }
        }
        
        binding.buttonPrevious.setOnClickListener {
            val currentItem = binding.viewPager.currentItem
            if (currentItem > 0) {
                binding.viewPager.currentItem = currentItem - 1
            }
        }
        
        binding.buttonSkip.setOnClickListener {
            // Skip to the end
            binding.viewPager.currentItem = pagerAdapter.itemCount - 1
        }
    }
    
    private fun updateNavigationButtons(position: Int) {
        val isLastPage = position == pagerAdapter.itemCount - 1
        val isFirstPage = position == 0
        
        binding.buttonPrevious.visibility = if (isFirstPage) android.view.View.INVISIBLE else android.view.View.VISIBLE
        binding.buttonNext.text = if (isLastPage) getString(R.string.get_started) else getString(R.string.next)
        binding.buttonSkip.visibility = if (isLastPage) android.view.View.INVISIBLE else android.view.View.VISIBLE
    }
    
    private fun completeOnboarding() {
        // Get data from fragments and complete setup
        val fragments = pagerAdapter.getFragments()
        
        // Get user data from welcome fragment
        val welcomeFragment = fragments[0] as? WelcomeFragment
        val username = welcomeFragment?.getUsername() ?: ""
        val password = welcomeFragment?.getPassword() ?: ""
        val major = welcomeFragment?.getMajor() ?: ""
        
        // Get security settings from security fragment
        val securityFragment = fragments[1] as? SecuritySetupFragment
        val authMethod = securityFragment?.getSelectedAuthMethod() ?: ""
        val pin = securityFragment?.getPin() ?: ""
        val securityQuestion = securityFragment?.getSecurityQuestion() ?: ""
        val securityAnswer = securityFragment?.getSecurityAnswer() ?: ""
        
        // Validate required fields
        if (username.isEmpty() || password.isEmpty() || major.isEmpty()) {
            showError("Please fill in all required fields")
            return
        }
        
        // Create user account
        viewModel.createUserAccount(
            username = username,
            password = password,
            major = major,
            authMethod = authMethod,
            pin = pin,
            securityQuestion = securityQuestion,
            securityAnswer = securityAnswer,
            biometricEnabled = authMethod.contains("biometric") && isBiometricAvailable()
        )
    }
    
    private fun isBiometricAvailable(): Boolean {
        val biometricManager = BiometricManager.from(this)
        return when (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS -> true
            else -> false
        }
    }
    
    private fun setButtonsEnabled(enabled: Boolean) {
        binding.buttonNext.isEnabled = enabled
        binding.buttonPrevious.isEnabled = enabled
        binding.buttonSkip.isEnabled = enabled
    }
    
    private fun showError(message: String) {
        binding.textError.text = message
        binding.textError.visibility = android.view.View.VISIBLE
    }
    
    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
