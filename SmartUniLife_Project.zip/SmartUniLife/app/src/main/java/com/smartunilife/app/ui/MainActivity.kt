package com.smartunilife.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.smartunilife.app.R
import com.smartunilife.app.databinding.ActivityMainBinding
import com.smartunilife.app.ui.auth.AuthActivity
import com.smartunilife.app.ui.onboarding.OnboardingActivity
import com.smartunilife.app.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration
    private val viewModel: MainViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        // Install splash screen
        val splashScreen = installSplashScreen()
        
        super.onCreate(savedInstanceState)
        
        // Keep splash screen visible while checking authentication
        splashScreen.setKeepOnScreenCondition {
            viewModel.isLoading.value == true
        }
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Setup navigation
        setupNavigation()
        
        // Observe authentication state
        observeAuthState()
        
        // Check if user is authenticated
        viewModel.checkAuthenticationState()
    }
    
    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController
        
        val bottomNavView: BottomNavigationView = binding.bottomNavigation
        bottomNavView.setupWithNavController(navController)
        
        // Setup action bar with navigation controller
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home,
                R.id.navigation_courses,
                R.id.navigation_assignments,
                R.id.navigation_schedule,
                R.id.navigation_statistics
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        
        // Handle navigation item selection
        bottomNavView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    navController.navigate(R.id.navigation_home)
                    true
                }
                R.id.navigation_courses -> {
                    navController.navigate(R.id.navigation_courses)
                    true
                }
                R.id.navigation_assignments -> {
                    navController.navigate(R.id.navigation_assignments)
                    true
                }
                R.id.navigation_schedule -> {
                    navController.navigate(R.id.navigation_schedule)
                    true
                }
                R.id.navigation_statistics -> {
                    navController.navigate(R.id.navigation_statistics)
                    true
                }
                else -> false
            }
        }
    }
    
    private fun observeAuthState() {
        lifecycleScope.launch {
            viewModel.authState.collect { authState ->
                when (authState) {
                    MainViewModel.AuthState.UNAUTHENTICATED -> {
                        // User needs to log in
                        startActivity(Intent(this@MainActivity, AuthActivity::class.java))
                        finish()
                    }
                    MainViewModel.AuthState.NEEDS_ONBOARDING -> {
                        // User needs to complete onboarding
                        startActivity(Intent(this@MainActivity, OnboardingActivity::class.java))
                        finish()
                    }
                    MainViewModel.AuthState.AUTHENTICATED -> {
                        // User is authenticated, continue with main app
                        // Navigation is already set up
                    }
                    MainViewModel.AuthState.LOADING -> {
                        // Show loading state (handled by splash screen)
                    }
                }
            }
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
    
    override fun onResume() {
        super.onResume()
        // Check authentication state when app resumes
        viewModel.checkAuthenticationState()
    }
}
