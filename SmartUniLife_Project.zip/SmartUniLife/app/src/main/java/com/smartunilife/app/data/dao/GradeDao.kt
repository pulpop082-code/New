package com.smartunilife.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.smartunilife.app.data.entity.GradeEntity

@Dao
interface GradeDao {
    
    @Query("SELECT * FROM grades WHERE courseOwnerId = :courseId ORDER BY date DESC")
    fun getGradesByCourseIdLiveData(courseId: Long): LiveData<List<GradeEntity>>
    
    @Query("SELECT * FROM grades WHERE courseOwnerId = :courseId ORDER BY date DESC")
    suspend fun getGradesByCourseId(courseId: Long): List<GradeEntity>
    
    @Query("SELECT * FROM grades WHERE gradeId = :gradeId")
    suspend fun getGradeById(gradeId: Long): GradeEntity?
    
    @Query("SELECT * FROM grades WHERE courseOwnerId = :courseId AND type = :type ORDER BY date DESC")
    suspend fun getGradesByType(courseId: Long, type: String): List<GradeEntity>
    
    @Query("SELECT AVG(score * 100.0 / maxScore) FROM grades WHERE courseOwnerId = :courseId")
    suspend fun getAverageGradePercentage(courseId: Long): Double?
    
    @Query("SELECT SUM(score * weight) / SUM(weight) FROM grades WHERE courseOwnerId = :courseId AND weight IS NOT NULL")
    suspend fun getWeightedAverageGrade(courseId: Long): Double?
    
    @Query("SELECT * FROM grades WHERE assignmentId = :assignmentId")
    suspend fun getGradeByAssignmentId(assignmentId: Long): GradeEntity?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrade(grade: GradeEntity): Long
    
    @Update
    suspend fun updateGrade(grade: GradeEntity)
    
    @Delete
    suspend fun deleteGrade(grade: GradeEntity)
    
    @Query("DELETE FROM grades WHERE gradeId = :gradeId")
    suspend fun deleteGradeById(gradeId: Long)
    
    @Query("DELETE FROM grades WHERE courseOwnerId = :courseId")
    suspend fun deleteGradesByCourseId(courseId: Long)
}
