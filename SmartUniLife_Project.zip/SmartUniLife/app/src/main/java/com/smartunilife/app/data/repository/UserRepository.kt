package com.smartunilife.app.data.repository

import androidx.lifecycle.LiveData
import com.smartunilife.app.data.dao.UserDao
import com.smartunilife.app.data.entity.UserEntity
import com.smartunilife.app.utils.SecurityUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserRepository(private val userDao: UserDao) {
    
    fun getCurrentUserLiveData(): LiveData<UserEntity?> = userDao.getCurrentUserLiveData()
    
    suspend fun getCurrentUser(): UserEntity? = withContext(Dispatchers.IO) {
        userDao.getCurrentUser()
    }
    
    suspend fun getUserByUsername(username: String): UserEntity? = withContext(Dispatchers.IO) {
        userDao.getUserByUsername(username)
    }
    
    suspend fun createUser(
        username: String,
        password: String,
        major: String,
        securityQuestion: String? = null,
        securityAnswer: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val salt = SecurityUtils.generateSalt()
            val passwordHash = SecurityUtils.hashPassword(password, salt)
            val securityAnswerHash = securityAnswer?.let { 
                SecurityUtils.hashPassword(it.lowercase().trim(), salt) 
            }
            
            val user = UserEntity(
                username = username,
                passwordHash = passwordHash,
                major = major,
                salt = salt,
                createdAt = System.currentTimeMillis(),
                securityQuestion = securityQuestion,
                securityAnswerHash = securityAnswerHash
            )
            
            userDao.insertUser(user)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun authenticateUser(username: String, password: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserByUsername(username) ?: return@withContext false
            val hashedPassword = SecurityUtils.hashPassword(password, user.salt)
            hashedPassword == user.passwordHash
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun updatePassword(username: String, newPassword: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val newSalt = SecurityUtils.generateSalt()
            val newPasswordHash = SecurityUtils.hashPassword(newPassword, newSalt)
            userDao.updatePassword(username, newPasswordHash, newSalt)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun updatePin(username: String, pin: String?, enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserByUsername(username) ?: return@withContext false
            val pinHash = pin?.let { SecurityUtils.hashPassword(it, user.salt) }
            userDao.updatePin(username, pinHash, enabled)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun verifyPin(username: String, pin: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserByUsername(username) ?: return@withContext false
            if (!user.pinEnabled || user.pinHash == null) return@withContext false
            val hashedPin = SecurityUtils.hashPassword(pin, user.salt)
            hashedPin == user.pinHash
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun updateBiometricEnabled(username: String, enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        try {
            userDao.updateBiometricEnabled(username, enabled)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun verifySecurityAnswer(username: String, answer: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserByUsername(username) ?: return@withContext false
            if (user.securityAnswerHash == null) return@withContext false
            val hashedAnswer = SecurityUtils.hashPassword(answer.lowercase().trim(), user.salt)
            hashedAnswer == user.securityAnswerHash
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun updateSecurityQuestion(username: String, question: String, answer: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserByUsername(username) ?: return@withContext false
            val answerHash = SecurityUtils.hashPassword(answer.lowercase().trim(), user.salt)
            userDao.updateSecurityQuestion(username, question, answerHash)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun deleteAllUsers(): Boolean = withContext(Dispatchers.IO) {
        try {
            userDao.deleteAllUsers()
            true
        } catch (e: Exception) {
            false
        }
    }
}
