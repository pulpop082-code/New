package com.smartunilife.app.data.repository

import androidx.lifecycle.LiveData
import com.smartunilife.app.data.dao.CourseDao
import com.smartunilife.app.data.dao.LectureDao
import com.smartunilife.app.data.dao.AssignmentDao
import com.smartunilife.app.data.dao.GradeDao
import com.smartunilife.app.data.entity.CourseEntity
import com.smartunilife.app.data.entity.LectureEntity
import com.smartunilife.app.data.entity.AssignmentEntity
import com.smartunilife.app.data.entity.GradeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CourseRepository(
    private val courseDao: CourseDao,
    private val lectureDao: LectureDao,
    private val assignmentDao: AssignmentDao,
    private val gradeDao: GradeDao
) {
    
    fun getAllCoursesLiveData(): LiveData<List<CourseEntity>> = courseDao.getAllCoursesLiveData()
    
    suspend fun getAllCourses(): List<CourseEntity> = withContext(Dispatchers.IO) {
        courseDao.getAllCourses()
    }
    
    suspend fun getCourseById(courseId: Long): CourseEntity? = withContext(Dispatchers.IO) {
        courseDao.getCourseById(courseId)
    }
    
    fun getCourseByIdLiveData(courseId: Long): LiveData<CourseEntity?> = 
        courseDao.getCourseByIdLiveData(courseId)
    
    suspend fun insertCourse(course: CourseEntity): Long = withContext(Dispatchers.IO) {
        courseDao.insertCourse(course)
    }
    
    suspend fun updateCourse(course: CourseEntity) = withContext(Dispatchers.IO) {
        courseDao.updateCourse(course)
    }
    
    suspend fun deleteCourse(course: CourseEntity) = withContext(Dispatchers.IO) {
        courseDao.deleteCourse(course)
    }
    
    suspend fun searchCourses(query: String): List<CourseEntity> = withContext(Dispatchers.IO) {
        courseDao.searchCourses("%$query%")
    }
    
    // Lecture operations
    fun getLecturesByCourseIdLiveData(courseId: Long): LiveData<List<LectureEntity>> = 
        lectureDao.getLecturesByCourseIdLiveData(courseId)
    
    suspend fun getLecturesByCourseId(courseId: Long): List<LectureEntity> = withContext(Dispatchers.IO) {
        lectureDao.getLecturesByCourseId(courseId)
    }
    
    suspend fun insertLecture(lecture: LectureEntity): Long = withContext(Dispatchers.IO) {
        lectureDao.insertLecture(lecture)
    }
    
    suspend fun updateLecture(lecture: LectureEntity) = withContext(Dispatchers.IO) {
        lectureDao.updateLecture(lecture)
    }
    
    suspend fun deleteLecture(lecture: LectureEntity) = withContext(Dispatchers.IO) {
        lectureDao.deleteLecture(lecture)
    }
    
    suspend fun updateLectureAttendance(lectureId: Long, attended: Boolean) = withContext(Dispatchers.IO) {
        lectureDao.updateAttendance(lectureId, attended)
    }
    
    // Assignment operations
    fun getAssignmentsByCourseIdLiveData(courseId: Long): LiveData<List<AssignmentEntity>> = 
        assignmentDao.getAssignmentsByCourseIdLiveData(courseId)
    
    suspend fun getAssignmentsByCourseId(courseId: Long): List<AssignmentEntity> = withContext(Dispatchers.IO) {
        assignmentDao.getAssignmentsByCourseId(courseId)
    }
    
    suspend fun insertAssignment(assignment: AssignmentEntity): Long = withContext(Dispatchers.IO) {
        assignmentDao.insertAssignment(assignment)
    }
    
    suspend fun updateAssignment(assignment: AssignmentEntity) = withContext(Dispatchers.IO) {
        assignmentDao.updateAssignment(assignment)
    }
    
    suspend fun deleteAssignment(assignment: AssignmentEntity) = withContext(Dispatchers.IO) {
        assignmentDao.deleteAssignment(assignment)
    }
    
    suspend fun updateAssignmentCompletion(assignmentId: Long, completed: Boolean) = withContext(Dispatchers.IO) {
        assignmentDao.updateCompletion(assignmentId, completed)
    }
    
    // Grade operations
    fun getGradesByCourseIdLiveData(courseId: Long): LiveData<List<GradeEntity>> = 
        gradeDao.getGradesByCourseIdLiveData(courseId)
    
    suspend fun getGradesByCourseId(courseId: Long): List<GradeEntity> = withContext(Dispatchers.IO) {
        gradeDao.getGradesByCourseId(courseId)
    }
    
    suspend fun insertGrade(grade: GradeEntity): Long = withContext(Dispatchers.IO) {
        gradeDao.insertGrade(grade)
    }
    
    suspend fun updateGrade(grade: GradeEntity) = withContext(Dispatchers.IO) {
        gradeDao.updateGrade(grade)
    }
    
    suspend fun deleteGrade(grade: GradeEntity) = withContext(Dispatchers.IO) {
        gradeDao.deleteGrade(grade)
    }
    
    suspend fun getAverageGradePercentage(courseId: Long): Double? = withContext(Dispatchers.IO) {
        gradeDao.getAverageGradePercentage(courseId)
    }
    
    suspend fun getWeightedAverageGrade(courseId: Long): Double? = withContext(Dispatchers.IO) {
        gradeDao.getWeightedAverageGrade(courseId)
    }
    
    // Statistics
    suspend fun getAttendanceRate(courseId: Long): Double = withContext(Dispatchers.IO) {
        val totalLectures = lectureDao.getTotalLecturesCount(courseId)
        val attendedLectures = lectureDao.getAttendedLecturesCount(courseId)
        
        if (totalLectures > 0) {
            (attendedLectures.toDouble() / totalLectures.toDouble()) * 100.0
        } else {
            0.0
        }
    }
    
    suspend fun getCompletionRate(courseId: Long): Double = withContext(Dispatchers.IO) {
        val totalAssignments = assignmentDao.getTotalAssignmentsCount(courseId)
        val completedAssignments = assignmentDao.getCompletedAssignmentsCount(courseId)
        
        if (totalAssignments > 0) {
            (completedAssignments.toDouble() / totalAssignments.toDouble()) * 100.0
        } else {
            0.0
        }
    }
    
    data class CourseStatistics(
        val course: CourseEntity,
        val totalLectures: Int,
        val attendedLectures: Int,
        val attendanceRate: Double,
        val totalAssignments: Int,
        val completedAssignments: Int,
        val completionRate: Double,
        val averageGrade: Double?
    )
    
    suspend fun getCourseStatistics(courseId: Long): CourseStatistics? = withContext(Dispatchers.IO) {
        val course = courseDao.getCourseById(courseId) ?: return@withContext null
        
        val totalLectures = lectureDao.getTotalLecturesCount(courseId)
        val attendedLectures = lectureDao.getAttendedLecturesCount(courseId)
        val attendanceRate = if (totalLectures > 0) {
            (attendedLectures.toDouble() / totalLectures.toDouble()) * 100.0
        } else 0.0
        
        val totalAssignments = assignmentDao.getTotalAssignmentsCount(courseId)
        val completedAssignments = assignmentDao.getCompletedAssignmentsCount(courseId)
        val completionRate = if (totalAssignments > 0) {
            (completedAssignments.toDouble() / totalAssignments.toDouble()) * 100.0
        } else 0.0
        
        val averageGrade = gradeDao.getAverageGradePercentage(courseId)
        
        CourseStatistics(
            course = course,
            totalLectures = totalLectures,
            attendedLectures = attendedLectures,
            attendanceRate = attendanceRate,
            totalAssignments = totalAssignments,
            completedAssignments = completedAssignments,
            completionRate = completionRate,
            averageGrade = averageGrade
        )
    }
}
