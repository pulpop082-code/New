package com.smartunilife.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartunilife.app.data.database.AppDatabase
import com.smartunilife.app.data.entity.AssignmentEntity
import com.smartunilife.app.data.entity.LectureEntity
import com.smartunilife.app.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.*

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = AppDatabase.getDatabase(application)
    private val userRepository = UserRepository(database.userDao())
    private val lectureDao = database.lectureDao()
    private val assignmentDao = database.assignmentDao()
    private val courseDao = database.courseDao()
    
    private val _todayLectures = MutableStateFlow<List<LectureEntity>>(emptyList())
    val todayLectures: StateFlow<List<LectureEntity>> = _todayLectures.asStateFlow()
    
    private val _upcomingAssignments = MutableStateFlow<List<AssignmentEntity>>(emptyList())
    val upcomingAssignments: StateFlow<List<AssignmentEntity>> = _upcomingAssignments.asStateFlow()
    
    private val _quickActions = MutableStateFlow<List<QuickAction>>(emptyList())
    val quickActions: StateFlow<List<QuickAction>> = _quickActions.asStateFlow()
    
    private val _weeklyOverview = MutableStateFlow(WeeklyOverview())
    val weeklyOverview: StateFlow<WeeklyOverview> = _weeklyOverview.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    data class QuickAction(
        val id: String,
        val title: String,
        val icon: Int,
        val color: Int
    )
    
    data class WeeklyOverview(
        val totalLectures: Int = 0,
        val attendedLectures: Int = 0,
        val totalAssignments: Int = 0,
        val completedAssignments: Int = 0,
        val pendingAssignments: Int = 0
    )
    
    init {
        setupQuickActions()
    }
    
    private fun setupQuickActions() {
        val actions = listOf(
            QuickAction(
                id = "add_course",
                title = "Add Course",
                icon = android.R.drawable.ic_input_add,
                color = android.graphics.Color.BLUE
            ),
            QuickAction(
                id = "add_lecture",
                title = "Add Lecture",
                icon = android.R.drawable.ic_menu_my_calendar,
                color = android.graphics.Color.GREEN
            ),
            QuickAction(
                id = "add_assignment",
                title = "Add Assignment",
                icon = android.R.drawable.ic_menu_agenda,
                color = android.graphics.Color.MAGENTA
            ),
            QuickAction(
                id = "add_makeup_lecture",
                title = "Makeup Lecture",
                icon = android.R.drawable.ic_menu_recent_history,
                color = android.graphics.Color.RED
            )
        )
        _quickActions.value = actions
    }
    
    fun loadDashboardData() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                loadTodayLectures()
                loadUpcomingAssignments()
                loadWeeklyOverview()
            } catch (e: Exception) {
                // Handle error
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    private suspend fun loadTodayLectures() {
        val calendar = Calendar.getInstance()
        val startOfDay = calendar.apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        
        val endOfDay = calendar.apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis
        
        val lectures = lectureDao.getLecturesInTimeRange(startOfDay, endOfDay)
        _todayLectures.value = lectures
    }
    
    private suspend fun loadUpcomingAssignments() {
        val currentTime = System.currentTimeMillis()
        val assignments = assignmentDao.getUpcomingAssignments(currentTime)
        _upcomingAssignments.value = assignments.take(5) // Show only first 5
    }
    
    private suspend fun loadWeeklyOverview() {
        val calendar = Calendar.getInstance()
        
        // Get start of week (Monday)
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfWeek = calendar.timeInMillis
        
        // Get end of week (Sunday)
        calendar.add(Calendar.DAY_OF_WEEK, 6)
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val endOfWeek = calendar.timeInMillis
        
        // Get weekly lectures
        val weeklyLectures = lectureDao.getLecturesInTimeRange(startOfWeek, endOfWeek)
        val attendedLectures = weeklyLectures.count { it.attended }
        
        // Get weekly assignments
        val weeklyAssignments = assignmentDao.getAssignmentsInTimeRange(startOfWeek, endOfWeek)
        val completedAssignments = weeklyAssignments.count { it.completed }
        val pendingAssignments = weeklyAssignments.count { !it.completed }
        
        _weeklyOverview.value = WeeklyOverview(
            totalLectures = weeklyLectures.size,
            attendedLectures = attendedLectures,
            totalAssignments = weeklyAssignments.size,
            completedAssignments = completedAssignments,
            pendingAssignments = pendingAssignments
        )
    }
    
    fun refreshData() {
        loadDashboardData()
    }
    
    fun onLectureClicked(lecture: LectureEntity) {
        // Navigate to lecture detail
        // This would typically use Navigation Component
    }
    
    fun onAssignmentClicked(assignment: AssignmentEntity) {
        // Navigate to assignment detail
        // This would typically use Navigation Component
    }
    
    fun onQuickActionClicked(action: QuickAction) {
        when (action.id) {
            "add_course" -> {
                // Navigate to add course
            }
            "add_lecture" -> {
                // Navigate to add lecture
            }
            "add_assignment" -> {
                // Navigate to add assignment
            }
            "add_makeup_lecture" -> {
                // Navigate to add makeup lecture
            }
        }
    }
    
    fun navigateToStatistics() {
        // Navigate to statistics fragment
    }
    
    fun navigateToSchedule() {
        // Navigate to schedule fragment
    }
    
    fun navigateToAssignments() {
        // Navigate to assignments fragment
    }
}
