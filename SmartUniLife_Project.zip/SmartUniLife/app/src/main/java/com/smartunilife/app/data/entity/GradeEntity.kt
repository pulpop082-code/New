package com.smartunilife.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "grades",
    foreignKeys = [ForeignKey(
        entity = CourseEntity::class,
        parentColumns = ["courseId"],
        childColumns = ["courseOwnerId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class GradeEntity(
    @PrimaryKey(autoGenerate = true) val gradeId: Long = 0,
    val courseOwnerId: Long,
    val type: String, // Assignment/Quiz/Midterm/Final
    val title: String?,
    val score: Float,
    val maxScore: Float,
    val weight: Float? = null,
    val date: Long = System.currentTimeMillis(),
    val assignmentId: Long? = null // Link to assignment if applicable
)
