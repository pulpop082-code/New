package com.smartunilife.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.smartunilife.app.data.entity.CourseEntity

@Dao
interface CourseDao {
    
    @Query("SELECT * FROM courses ORDER BY name ASC")
    fun getAllCoursesLiveData(): LiveData<List<CourseEntity>>
    
    @Query("SELECT * FROM courses ORDER BY name ASC")
    suspend fun getAllCourses(): List<CourseEntity>
    
    @Query("SELECT * FROM courses WHERE courseId = :courseId")
    suspend fun getCourseById(courseId: Long): CourseEntity?
    
    @Query("SELECT * FROM courses WHERE courseId = :courseId")
    fun getCourseByIdLiveData(courseId: Long): LiveData<CourseEntity?>
    
    @Query("SELECT * FROM courses WHERE name LIKE :searchQuery OR code LIKE :searchQuery OR professorName LIKE :searchQuery")
    suspend fun searchCourses(searchQuery: String): List<CourseEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity): Long
    
    @Update
    suspend fun updateCourse(course: CourseEntity)
    
    @Delete
    suspend fun deleteCourse(course: CourseEntity)
    
    @Query("DELETE FROM courses WHERE courseId = :courseId")
    suspend fun deleteCourseById(courseId: Long)
    
    @Query("SELECT COUNT(*) FROM courses")
    suspend fun getCoursesCount(): Int
}
