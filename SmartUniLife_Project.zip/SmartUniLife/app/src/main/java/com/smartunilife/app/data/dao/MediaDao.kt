package com.smartunilife.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.smartunilife.app.data.entity.MediaEntity

@Dao
interface MediaDao {
    
    @Query("SELECT * FROM media WHERE lectureId = :lectureId ORDER BY createdAt DESC")
    fun getMediaByLectureIdLiveData(lectureId: Long): LiveData<List<MediaEntity>>
    
    @Query("SELECT * FROM media WHERE lectureId = :lectureId ORDER BY createdAt DESC")
    suspend fun getMediaByLectureId(lectureId: Long): List<MediaEntity>
    
    @Query("SELECT * FROM media WHERE courseId = :courseId ORDER BY createdAt DESC")
    fun getMediaByCourseIdLiveData(courseId: Long): LiveData<List<MediaEntity>>
    
    @Query("SELECT * FROM media WHERE courseId = :courseId ORDER BY createdAt DESC")
    suspend fun getMediaByCourseId(courseId: Long): List<MediaEntity>
    
    @Query("SELECT * FROM media WHERE assignmentId = :assignmentId ORDER BY createdAt DESC")
    suspend fun getMediaByAssignmentId(assignmentId: Long): List<MediaEntity>
    
    @Query("SELECT * FROM media WHERE mediaId = :mediaId")
    suspend fun getMediaById(mediaId: Long): MediaEntity?
    
    @Query("SELECT * FROM media WHERE mimeType LIKE :mimeTypePattern ORDER BY createdAt DESC")
    suspend fun getMediaByType(mimeTypePattern: String): List<MediaEntity>
    
    @Query("SELECT SUM(fileSize) FROM media")
    suspend fun getTotalMediaSize(): Long?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(media: MediaEntity): Long
    
    @Update
    suspend fun updateMedia(media: MediaEntity)
    
    @Delete
    suspend fun deleteMedia(media: MediaEntity)
    
    @Query("DELETE FROM media WHERE mediaId = :mediaId")
    suspend fun deleteMediaById(mediaId: Long)
    
    @Query("DELETE FROM media WHERE lectureId = :lectureId")
    suspend fun deleteMediaByLectureId(lectureId: Long)
    
    @Query("DELETE FROM media WHERE courseId = :courseId")
    suspend fun deleteMediaByCourseId(courseId: Long)
}
