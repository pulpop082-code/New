package com.smartunilife.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "media")
data class MediaEntity(
    @PrimaryKey(autoGenerate = true) val mediaId: Long = 0,
    val lectureId: Long?,
    val courseId: Long?,
    val assignmentId: Long?,
    val filePath: String,
    val fileName: String,
    val mimeType: String,
    val fileSize: Long,
    val createdAt: Long,
    val description: String? = null
)
