package com.smartunilife.app.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.smartunilife.app.R
import com.smartunilife.app.databinding.ActivityAuthBinding
import com.smartunilife.app.ui.MainActivity
import com.smartunilife.app.viewmodel.AuthViewModel
import kotlinx.coroutines.launch

class AuthActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityAuthBinding
    private val viewModel: AuthViewModel by viewModels()
    
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupBiometric()
        setupObservers()
        setupClickListeners()
        
        // Load user data
        viewModel.loadCurrentUser()
    }
    
    private fun setupBiometric() {
        val executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                showError(errString.toString())
            }
            
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                viewModel.onBiometricAuthSuccess()
            }
            
            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                showError(getString(R.string.biometric_prompt_negative))
            }
        })
        
        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_prompt_title))
            .setSubtitle(getString(R.string.biometric_prompt_subtitle))
            .setDescription(getString(R.string.biometric_prompt_description))
            .setNegativeButtonText(getString(R.string.biometric_prompt_negative))
            .build()
    }
    
    private fun setupObservers() {
        lifecycleScope.launch {
            viewModel.currentUser.collect { user ->
                if (user != null) {
                    binding.textUsername.text = user.username
                    binding.textMajor.text = user.major
                    
                    // Show appropriate authentication methods
                    binding.buttonBiometric.isEnabled = user.biometricEnabled && isBiometricAvailable()
                    binding.buttonPin.isEnabled = user.pinEnabled
                    
                    // Auto-trigger biometric if enabled and available
                    if (user.biometricEnabled && isBiometricAvailable()) {
                        showBiometricPrompt()
                    }
                } else {
                    // No user found, redirect to onboarding
                    finish()
                }
            }
        }
        
        lifecycleScope.launch {
            viewModel.authState.collect { state ->
                when (state) {
                    AuthViewModel.AuthState.LOADING -> {
                        binding.progressBar.visibility = android.view.View.VISIBLE
                        setButtonsEnabled(false)
                    }
                    AuthViewModel.AuthState.SUCCESS -> {
                        binding.progressBar.visibility = android.view.View.GONE
                        navigateToMain()
                    }
                    AuthViewModel.AuthState.ERROR -> {
                        binding.progressBar.visibility = android.view.View.GONE
                        setButtonsEnabled(true)
                    }
                    AuthViewModel.AuthState.IDLE -> {
                        binding.progressBar.visibility = android.view.View.GONE
                        setButtonsEnabled(true)
                    }
                }
            }
        }
        
        lifecycleScope.launch {
            viewModel.errorMessage.collect { message ->
                if (message.isNotEmpty()) {
                    showError(message)
                }
            }
        }
    }
    
    private fun setupClickListeners() {
        binding.buttonPassword.setOnClickListener {
            val password = binding.editPassword.text.toString()
            if (password.isNotEmpty()) {
                viewModel.authenticateWithPassword(password)
            } else {
                showError(getString(R.string.password))
            }
        }
        
        binding.buttonBiometric.setOnClickListener {
            showBiometricPrompt()
        }
        
        binding.buttonPin.setOnClickListener {
            showPinDialog()
        }
        
        binding.textForgotPin.setOnClickListener {
            showSecurityQuestionDialog()
        }
    }
    
    private fun showBiometricPrompt() {
        if (isBiometricAvailable()) {
            biometricPrompt.authenticate(promptInfo)
        } else {
            showError("Biometric authentication not available")
        }
    }
    
    private fun showPinDialog() {
        val dialog = PinDialogFragment { pin ->
            viewModel.authenticateWithPin(pin)
        }
        dialog.show(supportFragmentManager, "pin_dialog")
    }
    
    private fun showSecurityQuestionDialog() {
        lifecycleScope.launch {
            val user = viewModel.currentUser.value
            if (user?.securityQuestion != null) {
                val dialog = SecurityQuestionDialogFragment(user.securityQuestion) { answer ->
                    viewModel.verifySecurityAnswer(answer)
                }
                dialog.show(supportFragmentManager, "security_question_dialog")
            } else {
                showError("No security question set")
            }
        }
    }
    
    private fun isBiometricAvailable(): Boolean {
        val biometricManager = BiometricManager.from(this)
        return when (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS -> true
            else -> false
        }
    }
    
    private fun setButtonsEnabled(enabled: Boolean) {
        binding.buttonPassword.isEnabled = enabled
        binding.buttonBiometric.isEnabled = enabled
        binding.buttonPin.isEnabled = enabled
    }
    
    private fun showError(message: String) {
        binding.textError.text = message
        binding.textError.visibility = android.view.View.VISIBLE
    }
    
    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
