package com.smartunilife.app.notification

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.smartunilife.app.data.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AssignmentReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val assignmentId = inputData.getLong("assignment_id", -1)
            val courseName = inputData.getString("course_name") ?: ""
            val assignmentTitle = inputData.getString("assignment_title") ?: ""
            val dueTime = inputData.getLong("due_time", 0)
            val reminderOffset = inputData.getInt("reminder_offset", 0)
            
            if (assignmentId == -1L) {
                return@withContext Result.failure()
            }
            
            // Check if assignment still exists and is not completed
            val database = AppDatabase.getDatabase(applicationContext)
            val assignment = database.assignmentDao().getAssignmentById(assignmentId)
            
            if (assignment != null && !assignment.completed) {
                // Show notification
                val notificationManager = NotificationManager(applicationContext)
                notificationManager.showAssignmentNotification(
                    assignmentId = assignmentId,
                    courseName = courseName,
                    assignmentTitle = assignmentTitle,
                    dueTime = dueTime,
                    reminderOffset = reminderOffset
                )
            }
            
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
