package com.smartunilife.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.smartunilife.app.data.entity.AssignmentEntity

@Dao
interface AssignmentDao {
    
    @Query("SELECT * FROM assignments WHERE courseOwnerId = :courseId ORDER BY dueDateTime ASC")
    fun getAssignmentsByCourseIdLiveData(courseId: Long): LiveData<List<AssignmentEntity>>
    
    @Query("SELECT * FROM assignments WHERE courseOwnerId = :courseId ORDER BY dueDateTime ASC")
    suspend fun getAssignmentsByCourseId(courseId: Long): List<AssignmentEntity>
    
    @Query("SELECT * FROM assignments WHERE assignmentId = :assignmentId")
    suspend fun getAssignmentById(assignmentId: Long): AssignmentEntity?
    
    @Query("SELECT * FROM assignments WHERE assignmentId = :assignmentId")
    fun getAssignmentByIdLiveData(assignmentId: Long): LiveData<AssignmentEntity?>
    
    @Query("SELECT * FROM assignments WHERE dueDateTime BETWEEN :startTime AND :endTime ORDER BY dueDateTime ASC")
    suspend fun getAssignmentsInTimeRange(startTime: Long, endTime: Long): List<AssignmentEntity>
    
    @Query("SELECT * FROM assignments WHERE dueDateTime >= :currentTime AND completed = 0 ORDER BY dueDateTime ASC LIMIT 10")
    suspend fun getUpcomingAssignments(currentTime: Long): List<AssignmentEntity>
    
    @Query("SELECT * FROM assignments WHERE dueDateTime < :currentTime AND completed = 0")
    suspend fun getOverdueAssignments(currentTime: Long): List<AssignmentEntity>
    
    @Query("SELECT COUNT(*) FROM assignments WHERE courseOwnerId = :courseId AND completed = 1")
    suspend fun getCompletedAssignmentsCount(courseId: Long): Int
    
    @Query("SELECT COUNT(*) FROM assignments WHERE courseOwnerId = :courseId")
    suspend fun getTotalAssignmentsCount(courseId: Long): Int
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignment(assignment: AssignmentEntity): Long
    
    @Update
    suspend fun updateAssignment(assignment: AssignmentEntity)
    
    @Delete
    suspend fun deleteAssignment(assignment: AssignmentEntity)
    
    @Query("UPDATE assignments SET completed = :completed WHERE assignmentId = :assignmentId")
    suspend fun updateCompletion(assignmentId: Long, completed: Boolean)
    
    @Query("SELECT * FROM assignments WHERE dueDateTime BETWEEN :startTime AND :endTime AND completed = 0")
    suspend fun getAssignmentsDueThisWeek(startTime: Long, endTime: Long): List<AssignmentEntity>
}
