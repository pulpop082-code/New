package com.smartunilife.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val username: String,
    val passwordHash: String,
    val major: String,
    val salt: String,
    val createdAt: Long,
    val securityQuestion: String? = null,
    val securityAnswerHash: String? = null,
    val biometricEnabled: Boolean = false,
    val pinEnabled: Boolean = false,
    val pinHash: String? = null
)
