package com.smartunilife.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.smartunilife.app.data.entity.LectureEntity

@Dao
interface LectureDao {
    
    @Query("SELECT * FROM lectures WHERE courseOwnerId = :courseId ORDER BY dateTime ASC")
    fun getLecturesByCourseIdLiveData(courseId: Long): LiveData<List<LectureEntity>>
    
    @Query("SELECT * FROM lectures WHERE courseOwnerId = :courseId ORDER BY dateTime ASC")
    suspend fun getLecturesByCourseId(courseId: Long): List<LectureEntity>
    
    @Query("SELECT * FROM lectures WHERE lectureId = :lectureId")
    suspend fun getLectureById(lectureId: Long): LectureEntity?
    
    @Query("SELECT * FROM lectures WHERE lectureId = :lectureId")
    fun getLectureByIdLiveData(lectureId: Long): LiveData<LectureEntity?>
    
    @Query("SELECT * FROM lectures WHERE dateTime BETWEEN :startTime AND :endTime ORDER BY dateTime ASC")
    suspend fun getLecturesInTimeRange(startTime: Long, endTime: Long): List<LectureEntity>
    
    @Query("SELECT * FROM lectures WHERE dateTime >= :currentTime ORDER BY dateTime ASC LIMIT 5")
    suspend fun getUpcomingLectures(currentTime: Long): List<LectureEntity>
    
    @Query("SELECT * FROM lectures WHERE attended = 0 AND dateTime < :currentTime")
    suspend fun getMissedLectures(currentTime: Long): List<LectureEntity>
    
    @Query("SELECT COUNT(*) FROM lectures WHERE courseOwnerId = :courseId AND attended = 1")
    suspend fun getAttendedLecturesCount(courseId: Long): Int
    
    @Query("SELECT COUNT(*) FROM lectures WHERE courseOwnerId = :courseId")
    suspend fun getTotalLecturesCount(courseId: Long): Int
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLecture(lecture: LectureEntity): Long
    
    @Update
    suspend fun updateLecture(lecture: LectureEntity)
    
    @Delete
    suspend fun deleteLecture(lecture: LectureEntity)
    
    @Query("UPDATE lectures SET attended = :attended WHERE lectureId = :lectureId")
    suspend fun updateAttendance(lectureId: Long, attended: Boolean)
    
    @Query("UPDATE lectures SET notes = :notes WHERE lectureId = :lectureId")
    suspend fun updateNotes(lectureId: Long, notes: String?)
    
    @Query("UPDATE lectures SET audioFilePath = :audioPath WHERE lectureId = :lectureId")
    suspend fun updateAudioPath(lectureId: Long, audioPath: String?)
}
