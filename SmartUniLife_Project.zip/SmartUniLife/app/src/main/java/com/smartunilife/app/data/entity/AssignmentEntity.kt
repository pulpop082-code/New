package com.smartunilife.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "assignments",
    foreignKeys = [ForeignKey(
        entity = CourseEntity::class,
        parentColumns = ["courseId"],
        childColumns = ["courseOwnerId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class AssignmentEntity(
    @PrimaryKey(autoGenerate = true) val assignmentId: Long = 0,
    val courseOwnerId: Long,
    val title: String,
    val description: String?,
    val dueDateTime: Long,
    val weight: Float?,
    val completed: Boolean = false,
    val reminderOffsets: String? = null, // JSON array of reminder offsets in minutes
    val createdAt: Long = System.currentTimeMillis()
)
