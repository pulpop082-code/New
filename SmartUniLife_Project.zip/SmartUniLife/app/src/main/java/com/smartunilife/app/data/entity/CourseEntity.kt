package com.smartunilife.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val courseId: Long = 0,
    val name: String,
    val code: String?,
    val professorName: String?,
    val professorPhone: String?,
    val colorHex: String?,
    val createdAt: Long,
    val weeklySchedule: String? = null, // JSON string for weekly schedule
    val room: String? = null
)
