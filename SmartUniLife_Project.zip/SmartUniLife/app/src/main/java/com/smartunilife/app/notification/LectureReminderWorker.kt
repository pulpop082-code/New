package com.smartunilife.app.notification

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.smartunilife.app.data.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LectureReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val lectureId = inputData.getLong("lecture_id", -1)
            val courseName = inputData.getString("course_name") ?: ""
            val lectureTitle = inputData.getString("lecture_title") ?: ""
            val lectureTime = inputData.getLong("lecture_time", 0)
            val room = inputData.getString("room") ?: ""
            
            if (lectureId == -1L) {
                return@withContext Result.failure()
            }
            
            // Check if lecture still exists and is not attended
            val database = AppDatabase.getDatabase(applicationContext)
            val lecture = database.lectureDao().getLectureById(lectureId)
            
            if (lecture != null && !lecture.attended) {
                // Show notification
                val notificationManager = NotificationManager(applicationContext)
                notificationManager.showLectureNotification(
                    lectureId = lectureId,
                    courseName = courseName,
                    lectureTitle = lectureTitle,
                    room = room
                )
                
                // Schedule notification to be dismissed after lecture ends
                val lectureDuration = lecture.durationMinutes * 60 * 1000L // Convert to milliseconds
                val dismissTime = lectureTime + lectureDuration
                val currentTime = System.currentTimeMillis()
                
                if (dismissTime > currentTime) {
                    // Schedule dismissal work
                    scheduleDismissalWork(lectureId, dismissTime - currentTime)
                }
            }
            
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
    
    private fun scheduleDismissalWork(lectureId: Long, delay: Long) {
        // This would schedule another worker to dismiss the notification
        // after the lecture ends
    }
}
