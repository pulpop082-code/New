package com.smartunilife.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.smartunilife.app.R
import com.smartunilife.app.data.entity.AssignmentEntity
import com.smartunilife.app.data.entity.LectureEntity
import com.smartunilife.app.ui.MainActivity
import java.util.concurrent.TimeUnit

class NotificationManager(private val context: Context) {
    
    companion object {
        const val CHANNEL_LECTURES = "lectures_channel"
        const val CHANNEL_ASSIGNMENTS = "assignments_channel"
        const val CHANNEL_GENERAL = "general_channel"
        
        const val NOTIFICATION_ID_LECTURE = 1001
        const val NOTIFICATION_ID_ASSIGNMENT = 1002
        
        const val WORK_TAG_LECTURE_REMINDER = "lecture_reminder"
        const val WORK_TAG_ASSIGNMENT_REMINDER = "assignment_reminder"
    }
    
    init {
        createNotificationChannels()
    }
    
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Lecture reminders channel
            val lectureChannel = NotificationChannel(
                CHANNEL_LECTURES,
                context.getString(R.string.notification_channel_lectures),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for lecture reminders"
                enableVibration(true)
                setShowBadge(true)
            }
            
            // Assignment reminders channel
            val assignmentChannel = NotificationChannel(
                CHANNEL_ASSIGNMENTS,
                context.getString(R.string.notification_channel_assignments),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for assignment reminders"
                enableVibration(true)
                setShowBadge(true)
            }
            
            // General notifications channel
            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                context.getString(R.string.notification_channel_general),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "General app notifications"
            }
            
            notificationManager.createNotificationChannels(listOf(
                lectureChannel,
                assignmentChannel,
                generalChannel
            ))
        }
    }
    
    fun scheduleLectureReminder(lecture: LectureEntity, courseName: String) {
        val reminderTime = lecture.dateTime - TimeUnit.MINUTES.toMillis(15) // 15 minutes before
        val currentTime = System.currentTimeMillis()
        
        if (reminderTime > currentTime) {
            val delay = reminderTime - currentTime
            
            val workRequest = OneTimeWorkRequestBuilder<LectureReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(
                    "lecture_id" to lecture.lectureId,
                    "course_name" to courseName,
                    "lecture_title" to (lecture.title ?: "Lecture ${lecture.index}"),
                    "lecture_time" to lecture.dateTime,
                    "room" to (lecture.room ?: "")
                ))
                .addTag(WORK_TAG_LECTURE_REMINDER)
                .addTag("lecture_${lecture.lectureId}")
                .build()
            
            WorkManager.getInstance(context).enqueue(workRequest)
        }
    }
    
    fun scheduleAssignmentReminder(assignment: AssignmentEntity, courseName: String, reminderOffsetMinutes: Int) {
        val reminderTime = assignment.dueDateTime - TimeUnit.MINUTES.toMillis(reminderOffsetMinutes.toLong())
        val currentTime = System.currentTimeMillis()
        
        if (reminderTime > currentTime) {
            val delay = reminderTime - currentTime
            
            val workRequest = OneTimeWorkRequestBuilder<AssignmentReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(
                    "assignment_id" to assignment.assignmentId,
                    "course_name" to courseName,
                    "assignment_title" to assignment.title,
                    "due_time" to assignment.dueDateTime,
                    "reminder_offset" to reminderOffsetMinutes
                ))
                .addTag(WORK_TAG_ASSIGNMENT_REMINDER)
                .addTag("assignment_${assignment.assignmentId}")
                .build()
            
            WorkManager.getInstance(context).enqueue(workRequest)
        }
    }
    
    fun showLectureNotification(
        lectureId: Long,
        courseName: String,
        lectureTitle: String,
        room: String
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "lecture_detail")
            putExtra("lecture_id", lectureId)
        }
        
        val pendingIntent = PendingIntent.getActivity(
            context,
            lectureId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // Action buttons
        val attendedIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "ACTION_MARK_ATTENDED"
            putExtra("lecture_id", lectureId)
        }
        val attendedPendingIntent = PendingIntent.getBroadcast(
            context,
            lectureId.toInt() + 10000,
            attendedIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val recordIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "ACTION_START_RECORDING"
            putExtra("lecture_id", lectureId)
        }
        val recordPendingIntent = PendingIntent.getBroadcast(
            context,
            lectureId.toInt() + 20000,
            recordIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val notification = NotificationCompat.Builder(context, CHANNEL_LECTURES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.lecture_notification_title))
            .setContentText(context.getString(R.string.lecture_notification_text, "$courseName - $lectureTitle"))
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("$courseName - $lectureTitle\n${if (room.isNotEmpty()) "Room: $room" else ""}"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(false)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_check, "Attended", attendedPendingIntent)
            .addAction(R.drawable.ic_mic, "Record", recordPendingIntent)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        
        NotificationManagerCompat.from(context).notify(
            NOTIFICATION_ID_LECTURE + lectureId.toInt(),
            notification
        )
    }
    
    fun showAssignmentNotification(
        assignmentId: Long,
        courseName: String,
        assignmentTitle: String,
        dueTime: Long,
        reminderOffset: Int
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "assignment_detail")
            putExtra("assignment_id", assignmentId)
        }
        
        val pendingIntent = PendingIntent.getActivity(
            context,
            assignmentId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val timeText = when {
            reminderOffset >= 1440 -> "${reminderOffset / 1440} days"
            reminderOffset >= 60 -> "${reminderOffset / 60} hours"
            else -> "$reminderOffset minutes"
        }
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ASSIGNMENTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Assignment Due Soon")
            .setContentText("$courseName - $assignmentTitle")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("$courseName - $assignmentTitle\nDue in $timeText"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        
        NotificationManagerCompat.from(context).notify(
            NOTIFICATION_ID_ASSIGNMENT + assignmentId.toInt(),
            notification
        )
    }
    
    fun cancelLectureReminder(lectureId: Long) {
        WorkManager.getInstance(context).cancelAllWorkByTag("lecture_$lectureId")
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID_LECTURE + lectureId.toInt())
    }
    
    fun cancelAssignmentReminder(assignmentId: Long) {
        WorkManager.getInstance(context).cancelAllWorkByTag("assignment_$assignmentId")
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID_ASSIGNMENT + assignmentId.toInt())
    }
    
    fun cancelAllReminders() {
        WorkManager.getInstance(context).cancelAllWorkByTag(WORK_TAG_LECTURE_REMINDER)
        WorkManager.getInstance(context).cancelAllWorkByTag(WORK_TAG_ASSIGNMENT_REMINDER)
    }
}
