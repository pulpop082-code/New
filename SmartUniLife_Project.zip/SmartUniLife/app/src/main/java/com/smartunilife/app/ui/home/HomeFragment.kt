package com.smartunilife.app.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.smartunilife.app.databinding.FragmentHomeBinding
import com.smartunilife.app.ui.home.adapter.QuickActionsAdapter
import com.smartunilife.app.ui.home.adapter.TodayLecturesAdapter
import com.smartunilife.app.ui.home.adapter.UpcomingAssignmentsAdapter
import com.smartunilife.app.viewmodel.HomeViewModel
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    
    private val viewModel: HomeViewModel by viewModels()
    
    private lateinit var todayLecturesAdapter: TodayLecturesAdapter
    private lateinit var upcomingAssignmentsAdapter: UpcomingAssignmentsAdapter
    private lateinit var quickActionsAdapter: QuickActionsAdapter
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerViews()
        setupObservers()
        setupClickListeners()
        
        // Load data
        viewModel.loadDashboardData()
    }
    
    private fun setupRecyclerViews() {
        // Today's lectures
        todayLecturesAdapter = TodayLecturesAdapter { lecture ->
            // Handle lecture click
            viewModel.onLectureClicked(lecture)
        }
        binding.recyclerTodayLectures.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = todayLecturesAdapter
        }
        
        // Upcoming assignments
        upcomingAssignmentsAdapter = UpcomingAssignmentsAdapter { assignment ->
            // Handle assignment click
            viewModel.onAssignmentClicked(assignment)
        }
        binding.recyclerUpcomingAssignments.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = upcomingAssignmentsAdapter
        }
        
        // Quick actions
        quickActionsAdapter = QuickActionsAdapter { action ->
            // Handle quick action click
            viewModel.onQuickActionClicked(action)
        }
        binding.recyclerQuickActions.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = quickActionsAdapter
        }
    }
    
    private fun setupObservers() {
        viewLifecycleOwner.lifecycleScope.launch {
            // Observe today's lectures
            viewModel.todayLectures.collect { lectures ->
                todayLecturesAdapter.submitList(lectures)
                binding.textNoLecturesToday.visibility = 
                    if (lectures.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        
        viewLifecycleOwner.lifecycleScope.launch {
            // Observe upcoming assignments
            viewModel.upcomingAssignments.collect { assignments ->
                upcomingAssignmentsAdapter.submitList(assignments)
                binding.textNoUpcomingAssignments.visibility = 
                    if (assignments.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        
        viewLifecycleOwner.lifecycleScope.launch {
            // Observe quick actions
            viewModel.quickActions.collect { actions ->
                quickActionsAdapter.submitList(actions)
            }
        }
        
        viewLifecycleOwner.lifecycleScope.launch {
            // Observe weekly overview
            viewModel.weeklyOverview.collect { overview ->
                binding.textTotalLectures.text = overview.totalLectures.toString()
                binding.textAttendedLectures.text = overview.attendedLectures.toString()
                binding.textPendingAssignments.text = overview.pendingAssignments.toString()
                binding.textCompletedAssignments.text = overview.completedAssignments.toString()
                
                // Update progress bars
                val attendanceProgress = if (overview.totalLectures > 0) {
                    (overview.attendedLectures * 100) / overview.totalLectures
                } else 0
                binding.progressAttendance.progress = attendanceProgress
                
                val assignmentProgress = if (overview.totalAssignments > 0) {
                    (overview.completedAssignments * 100) / overview.totalAssignments
                } else 0
                binding.progressAssignments.progress = assignmentProgress
            }
        }
        
        viewLifecycleOwner.lifecycleScope.launch {
            // Observe loading state
            viewModel.isLoading.collect { isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }
    
    private fun setupClickListeners() {
        binding.cardWeeklyOverview.setOnClickListener {
            // Navigate to statistics
            viewModel.navigateToStatistics()
        }
        
        binding.buttonViewAllLectures.setOnClickListener {
            // Navigate to schedule
            viewModel.navigateToSchedule()
        }
        
        binding.buttonViewAllAssignments.setOnClickListener {
            // Navigate to assignments
            viewModel.navigateToAssignments()
        }
        
        // Swipe to refresh
        binding.swipeRefreshLayout.setOnRefreshListener {
            viewModel.refreshData()
            binding.swipeRefreshLayout.isRefreshing = false
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
