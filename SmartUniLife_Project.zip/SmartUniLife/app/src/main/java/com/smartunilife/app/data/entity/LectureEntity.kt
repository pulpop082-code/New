package com.smartunilife.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "lectures",
    foreignKeys = [ForeignKey(
        entity = CourseEntity::class,
        parentColumns = ["courseId"],
        childColumns = ["courseOwnerId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class LectureEntity(
    @PrimaryKey(autoGenerate = true) val lectureId: Long = 0,
    val courseOwnerId: Long,
    val index: Int,
    val title: String?,
    val dateTime: Long, // epoch millis
    val durationMinutes: Int,
    val room: String?,
    val attended: Boolean = false,
    val notes: String?,
    val audioFilePath: String? = null,
    val isRecording: Boolean = false
)
