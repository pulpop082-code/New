# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# Keep Room entities
-keep class com.smartunilife.app.data.entity.** { *; }

# Keep Room DAOs
-keep class com.smartunilife.app.data.dao.** { *; }

# Keep ViewModels
-keep class com.smartunilife.app.viewmodel.** { *; }

# Keep Repositories
-keep class com.smartunilife.app.data.repository.** { *; }

# Keep security utils
-keep class com.smartunilife.app.utils.SecurityUtils { *; }

# Keep backup classes
-keep class com.smartunilife.app.backup.** { *; }

# Keep notification classes
-keep class com.smartunilife.app.notification.** { *; }

# Room specific rules
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Biometric library
-keep class androidx.biometric.** { *; }

# WorkManager
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.InputMerger
-keep class androidx.work.impl.background.systemalarm.RescheduleReceiver

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }

# Gson (if used for JSON parsing)
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Material Design Components
-keep class com.google.android.material.** { *; }

# Navigation Component
-keep class androidx.navigation.** { *; }

# Lifecycle components
-keep class androidx.lifecycle.** { *; }

# Fragment
-keep class androidx.fragment.** { *; }
